# SemesterProject25_1

a fair restaurant check management algorithm for distributing tips utilizing loops

kyle f, jacob n, joey m

Java intelliJ
